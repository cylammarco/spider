#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Usage: python pgmtofits.py "*.pgm"
or python pgmtofits.py mypgmfile.pgm

Take a list of, or wildcard search for, a bunch of PGM files and
convert them to FITS files.

Sandy Rogers, November 2012
abr@roe.ac.uk
"""

import numpy as np
import sys
import pyfits
import glob
import os
import struct
import re

def readPGMP5(filename, byteorder='>'):
    with open(filename, 'rb') as f:
        buffer = f.read()
    try:
        header, width, height, maxval = re.search(
            b"(^P5\s(?:\s*#.*[\r\n])*"
            b"(\d+)\s(?:\s*#.*[\r\n])*"
            b"(\d+)\s(?:\s*#.*[\r\n])*"
            b"(\d+)\s(?:\s*#.*[\r\n]\s)*)", buffer).groups()
    except AttributeError:
        raise ValueError("Not a raw PGM file: '%s'" % filename)
    return np.frombuffer(buffer,
                            dtype='u1' if int(maxval) < 256 else byteorder+'u2',
                            count=int(width)*int(height),
                            offset=len(header)
                            ).reshape((int(height), int(width)))


def readPGMP2(infile, width, height):
    restoffile = infile.readlines()
    allnums = []
    for line in restoffile:
        thisline = [float(it) for it in line.split()]
        allnums.append(thisline)
    allnums = [item for sublist in allnums for item in sublist]
    allnums = np.array(allnums)
    allnumsrs = allnums.reshape(height, width)
    return allnumsrs


if __name__ == "__main__":
    try:
        pgmfiles = glob.glob(sys.argv[1])
    except:
        print 'I didn\'t understand your file input.'
        print __doc__
        exit
    if len(pgmfiles) < 1:
        print 'No files in this folder matched your search string!'
        exit
    else:
        print 'I\'ve found %d .pgm file(s) matching your search.' \
% len(pgmfiles)
    for pgmfile in pgmfiles:
        print 'Converting %s to FITS. Hold tight!' % pgmfile
        with open(pgmfile, 'r') as infile:
            if not pgmfile[-4:] == '.pgm':
                raise UserWarning('Your file doesn\t end .pgm. I\'m stuck.')
            pgmtype = infile.readline()
            if pgmtype.strip() == 'P2':
                wh = infile.readline()
                try:
                    ws, hs = wh.split()
                    width = int(ws)
                    height = int(hs)
                    print 'Picture is %d x %d pixels' % (width, height)
                except:
                    raise UserWarning('I couldn\'t get the image size from\
that file so I\'m stuck. Check its P2 PGM.')
                    exit
                try:
                    maxval = float(infile.readline())
                except:
                    raise UserWarning('I couldn\'t get the MAXVAL from\
that file so I\'m stuck. Check its P2 PGM.')
                    exit
                image = readPGMP2(infile, width, height)
            elif pgmtype.strip() == 'P5':
                image = readPGMP5(pgmfile)
            filenamebasename = os.path.basename(pgmfile)[:-4]
            filenameprefix = filenamebasename.split('_201')[0]
            filenameending = filenamebasename.split('-')[-1][2:]
            fitsfile = filenameprefix + filenameending + '.fits'
            fitsfile = os.path.join(os.path.dirname(pgmfile), fitsfile)
            pyfits.writeto(fitsfile, image, clobber=True)
            print 'Wrote the fits file %s' % os.path.basename(fitsfile)
