__svn_version__ = 'exported'

__full_svn_info__ = '''
unknown'''

import datetime # setupdate
setupdate = datetime.datetime(2011, 7, 31, 11, 16, 14, 687515) # setupdate
